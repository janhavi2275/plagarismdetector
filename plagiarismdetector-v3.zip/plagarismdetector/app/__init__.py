"""SemanticEye Application Package"""
