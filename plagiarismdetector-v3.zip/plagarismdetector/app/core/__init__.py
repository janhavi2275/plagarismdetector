"""SemanticEye Core Package"""
